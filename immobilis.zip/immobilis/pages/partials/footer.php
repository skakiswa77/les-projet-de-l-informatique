<footer class="row p-5 bg-warning">
    <div class="col">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam, animi consequuntur cum debitis delectus ducimus error eum expedita incidunt inventore iste iure laboriosam libero officia quae quidem sapiente sunt ullam.</div>
    <div class="col">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, asperiores at atque, blanditiis consequatur cupiditate dignissimos doloremque earum illum itaque iusto laborum magni, minima nam neque provident rem repellat sed?</div>
    <div class="col">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores at, atque aut deserunt dicta dolorem eaque eius enim error et explicabo illo iusto omnis quia, quis rerum totam velit veniam.</div>
</footer>

<?php
unset($_SESSION["success"]);
unset($_SESSION["error"]);

?>
</body>
</html>