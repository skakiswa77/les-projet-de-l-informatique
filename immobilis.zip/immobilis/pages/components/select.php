<?php
$label ??="";
$name ?? "";
$value  ??"";
$multiple ??"";

?>

<div class="form-group">

<select class="form_control" name="<?=$name?>" id="<?=$name?>">
<?php foreach($value as $v): ?>
    <option 
    
    value=""><?=$v["id"]?>"><?=$v["name"]?>
    </option>
    <?php endforeach; ?>
</select>

</div>