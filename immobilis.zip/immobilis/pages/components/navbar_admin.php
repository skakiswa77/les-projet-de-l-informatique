<nav class="navbar bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="pages/admin/dashboard.php">Tableau de bord</a>
        <form method="post" action="pages/admin/logout.php">
            <button class="btn btn-info">Se deconnecter</button>
        </form>
    </div>
</nav>
